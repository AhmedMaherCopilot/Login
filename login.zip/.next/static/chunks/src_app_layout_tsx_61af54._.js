(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/_620847._.js",
    "static/chunks/_212984._.css"
  ],
  "source": "dynamic"
});
