(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cart_page_tsx_3a5b8a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cart_page_tsx_3a5b8a._.js",
  "chunks": [
    "static/chunks/_8f2e6c._.js"
  ],
  "source": "dynamic"
});
