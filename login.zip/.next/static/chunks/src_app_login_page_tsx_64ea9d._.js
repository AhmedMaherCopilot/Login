(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_login_page_tsx_64ea9d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_login_page_tsx_64ea9d._.js",
  "chunks": [
    "static/chunks/src_app_login_page_tsx_9ae2fd._.js"
  ],
  "source": "dynamic"
});
