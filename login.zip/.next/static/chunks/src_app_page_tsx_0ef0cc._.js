(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_0ef0cc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_0ef0cc._.js",
  "chunks": [
    "static/chunks/src_app_page_module_d12eb7.css",
    "static/chunks/_58c17a._.js"
  ],
  "source": "dynamic"
});
