(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_43f059._.js", {

"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Page)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$spinners$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-spinners/index.js [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../page.module.css'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
function Page() {
    _s();
    const [data, setdata] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    async function getAlldata() {
        setLoading(true);
        try {
            const response = await fetch('https://www.themealdb.com/api/json/v1/1/data.php');
            const data = await response.json();
            setdata(data.data || []); // Ensure it's always an array
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally{
            setLoading(false);
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            getAlldata();
        }
    }["Page.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: styles.page,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: "data"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 30,
                columnNumber: 13
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$spinners$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FadeLoader"], {
                className: ""
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 31,
                columnNumber: 24
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                children: data.map((category, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            data.strCategoryThumb && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Image, {
                                src: category.strCategoryThumb,
                                alt: category.strCategory,
                                width: 100,
                                height: 100
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 37,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: category.strCategory
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 44,
                                columnNumber: 25
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 35,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 33,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 29,
        columnNumber: 9
    }, this);
}
_s(Page, "y3HZIUOuejZN2gm/N86Itj+xvSw=");
_c = Page;
var _c;
__turbopack_refresh__.register(_c, "Page");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
"[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createAnimation = void 0;
var createAnimation = function(loaderName, frames, suffix) {
    var animationName = "react-spinners-".concat(loaderName, "-").concat(suffix);
    if (typeof window == "undefined" || !window.document) {
        return animationName;
    }
    var styleEl = document.createElement("style");
    document.head.appendChild(styleEl);
    var styleSheet = styleEl.sheet;
    var keyFrames = "\n    @keyframes ".concat(animationName, " {\n      ").concat(frames, "\n    }\n  ");
    if (styleSheet) {
        styleSheet.insertRule(keyFrames, 0);
    }
    return animationName;
};
exports.createAnimation = createAnimation;
}}),
"[project]/node_modules/react-spinners/helpers/colors.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.calculateRgba = void 0;
var BasicColors;
(function(BasicColors) {
    BasicColors["maroon"] = "#800000";
    BasicColors["red"] = "#FF0000";
    BasicColors["orange"] = "#FFA500";
    BasicColors["yellow"] = "#FFFF00";
    BasicColors["olive"] = "#808000";
    BasicColors["green"] = "#008000";
    BasicColors["purple"] = "#800080";
    BasicColors["fuchsia"] = "#FF00FF";
    BasicColors["lime"] = "#00FF00";
    BasicColors["teal"] = "#008080";
    BasicColors["aqua"] = "#00FFFF";
    BasicColors["blue"] = "#0000FF";
    BasicColors["navy"] = "#000080";
    BasicColors["black"] = "#000000";
    BasicColors["gray"] = "#808080";
    BasicColors["silver"] = "#C0C0C0";
    BasicColors["white"] = "#FFFFFF";
})(BasicColors || (BasicColors = {}));
var handleRgbColorString = function(color, opacity) {
    // rgb(a)(255 255 255 / 80%)
    if (color.includes("/")) {
        return color.replace("rgb(", "rgba(");
    }
    var rgbValues = color.substring(color.startsWith("rgba(") ? 5 : 4, color.length - 1).trim();
    var splittedByCommas = rgbValues.split(",");
    // rgb(a)(255, 255, 255, 0.8)
    if (splittedByCommas.length === 4) {
        return color.replace("rgb(", "rgba(");
    }
    // rgb(a)(255, 255, 255)
    if (splittedByCommas.length === 3) {
        return "rgba(".concat(rgbValues, ", ").concat(opacity, ")");
    }
    // rgb(a)(255 255 255)
    return "rgba(".concat(rgbValues, " / ").concat(opacity, ")");
};
var calculateRgba = function(color, opacity) {
    if (color.startsWith("rgb")) {
        return handleRgbColorString(color, opacity);
    }
    if (Object.keys(BasicColors).includes(color)) {
        color = BasicColors[color];
    }
    if (color[0] === "#") {
        color = color.slice(1);
    }
    if (color.length === 3) {
        var res_1 = "";
        color.split("").forEach(function(c) {
            res_1 += c;
            res_1 += c;
        });
        color = res_1;
    }
    var rgbValues = (color.match(/.{2}/g) || []).map(function(hex) {
        return parseInt(hex, 16);
    }).join(", ");
    return "rgba(".concat(rgbValues, ", ").concat(opacity, ")");
};
exports.calculateRgba = calculateRgba;
}}),
"[project]/node_modules/react-spinners/BarLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var colors_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/colors.js [app-client] (ecmascript)");
var long = (0, animation_1.createAnimation)("BarLoader", "0% {left: -35%;right: 100%} 60% {left: 100%;right: -90%} 100% {left: 100%;right: -90%}", "long");
var short = (0, animation_1.createAnimation)("BarLoader", "0% {left: -200%;right: 100%} 60% {left: 107%;right: -8%} 100% {left: 107%;right: -8%}", "short");
function BarLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.height, height = _f === void 0 ? 4 : _f, _g = _a.width, width = _g === void 0 ? 100 : _g, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "height",
        "width"
    ]);
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(width),
        height: (0, unitConverter_1.cssValue)(height),
        overflow: "hidden",
        backgroundColor: (0, colors_1.calculateRgba)(color, 0.2),
        backgroundClip: "padding-box"
    }, cssOverride);
    var style = function(i) {
        return {
            position: "absolute",
            height: (0, unitConverter_1.cssValue)(height),
            overflow: "hidden",
            backgroundColor: color,
            backgroundClip: "padding-box",
            display: "block",
            borderRadius: 2,
            willChange: "left, right",
            animationFillMode: "forwards",
            animation: "".concat(i === 1 ? long : short, " ").concat(2.1 / speedMultiplier, "s ").concat(i === 2 ? "".concat(1.15 / speedMultiplier, "s") : "", " ").concat(i === 1 ? "cubic-bezier(0.65, 0.815, 0.735, 0.395)" : "cubic-bezier(0.165, 0.84, 0.44, 1)", " infinite")
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }));
}
exports.default = BarLoader;
}}),
"[project]/node_modules/react-spinners/BeatLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var beat = (0, animation_1.createAnimation)("BeatLoader", "50% {transform: scale(0.75);opacity: 0.2} 100% {transform: scale(1);opacity: 1}", "beat");
function BeatLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 15 : _f, _g = _a.margin, margin = _g === void 0 ? 2 : _g, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size",
        "margin"
    ]);
    var wrapper = __assign({
        display: "inherit"
    }, cssOverride);
    var style = function(i) {
        return {
            display: "inline-block",
            backgroundColor: color,
            width: (0, unitConverter_1.cssValue)(size),
            height: (0, unitConverter_1.cssValue)(size),
            margin: (0, unitConverter_1.cssValue)(margin),
            borderRadius: "100%",
            animation: "".concat(beat, " ").concat(0.7 / speedMultiplier, "s ").concat(i % 2 ? "0s" : "".concat(0.35 / speedMultiplier, "s"), " infinite linear"),
            animationFillMode: "both"
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }), React.createElement("span", {
        style: style(3)
    }));
}
exports.default = BeatLoader;
}}),
"[project]/node_modules/react-spinners/BounceLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var bounce = (0, animation_1.createAnimation)("BounceLoader", "0% {transform: scale(0)} 50% {transform: scale(1.0)} 100% {transform: scale(0)}", "bounce");
function BounceLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 60 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var style = function(i) {
        var animationTiming = i === 1 ? "".concat(1 / speedMultiplier, "s") : "0s";
        return {
            position: "absolute",
            height: (0, unitConverter_1.cssValue)(size),
            width: (0, unitConverter_1.cssValue)(size),
            backgroundColor: color,
            borderRadius: "100%",
            opacity: 0.6,
            top: 0,
            left: 0,
            animationFillMode: "both",
            animation: "".concat(bounce, " ").concat(2.1 / speedMultiplier, "s ").concat(animationTiming, " infinite ease-in-out")
        };
    };
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size)
    }, cssOverride);
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }));
}
exports.default = BounceLoader;
}}),
"[project]/node_modules/react-spinners/CircleLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var circle = (0, animation_1.createAnimation)("CircleLoader", "0% {transform: rotate(0deg)} 50% {transform: rotate(180deg)} 100% {transform: rotate(360deg)}", "circle");
function CircleLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 50 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size)
    }, cssOverride);
    var style = function(i) {
        var _a = (0, unitConverter_1.parseLengthAndUnit)(size), value = _a.value, unit = _a.unit;
        return {
            position: "absolute",
            height: "".concat(value * (1 - i / 10)).concat(unit),
            width: "".concat(value * (1 - i / 10)).concat(unit),
            borderTop: "1px solid ".concat(color),
            borderBottom: "none",
            borderLeft: "1px solid ".concat(color),
            borderRight: "none",
            borderRadius: "100%",
            transition: "2s",
            top: "".concat(i * 0.7 * 2.5, "%"),
            left: "".concat(i * 0.35 * 2.5, "%"),
            animation: "".concat(circle, " ").concat(1 / speedMultiplier, "s ").concat(i * 0.2 / speedMultiplier, "s infinite linear")
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(0)
    }), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }), React.createElement("span", {
        style: style(3)
    }), React.createElement("span", {
        style: style(4)
    }));
}
exports.default = CircleLoader;
}}),
"[project]/node_modules/react-spinners/ClimbingBoxLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var climbingBox = (0, animation_1.createAnimation)("ClimbingBoxLoader", "0% {transform:translate(0, -1em) rotate(-45deg)}\n  5% {transform:translate(0, -1em) rotate(-50deg)}\n  20% {transform:translate(1em, -2em) rotate(47deg)}\n  25% {transform:translate(1em, -2em) rotate(45deg)}\n  30% {transform:translate(1em, -2em) rotate(40deg)}\n  45% {transform:translate(2em, -3em) rotate(137deg)}\n  50% {transform:translate(2em, -3em) rotate(135deg)}\n  55% {transform:translate(2em, -3em) rotate(130deg)}\n  70% {transform:translate(3em, -4em) rotate(217deg)}\n  75% {transform:translate(3em, -4em) rotate(220deg)}\n  100% {transform:translate(0, -1em) rotate(-225deg)}", "climbingBox");
function ClimbingBoxLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 15 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var container = __assign({
        display: "inherit",
        position: "relative",
        width: "7.1em",
        height: "7.1em"
    }, cssOverride);
    var wrapper = {
        position: "absolute",
        top: "50%",
        left: "50%",
        marginTop: "-2.7em",
        marginLeft: "-2.7em",
        width: "5.4em",
        height: "5.4em",
        fontSize: (0, unitConverter_1.cssValue)(size)
    };
    var style = {
        position: "absolute",
        left: "0",
        bottom: "-0.1em",
        height: "1em",
        width: "1em",
        backgroundColor: "transparent",
        borderRadius: "15%",
        border: "0.25em solid ".concat(color),
        transform: "translate(0, -1em) rotate(-45deg)",
        animationFillMode: "both",
        animation: "".concat(climbingBox, " ").concat(2.5 / speedMultiplier, "s infinite cubic-bezier(0.79, 0, 0.47, 0.97)")
    };
    var hill = {
        position: "absolute",
        width: "7.1em",
        height: "7.1em",
        top: "1.7em",
        left: "1.7em",
        borderLeft: "0.25em solid ".concat(color),
        transform: "rotate(45deg)"
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: container
    }, additionalprops), React.createElement("span", {
        style: wrapper
    }, React.createElement("span", {
        style: style
    }), React.createElement("span", {
        style: hill
    })));
}
exports.default = ClimbingBoxLoader;
}}),
"[project]/node_modules/react-spinners/ClipLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var clip = (0, animation_1.createAnimation)("ClipLoader", "0% {transform: rotate(0deg) scale(1)} 50% {transform: rotate(180deg) scale(0.8)} 100% {transform: rotate(360deg) scale(1)}", "clip");
function ClipLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 35 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var style = __assign({
        background: "transparent !important",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size),
        borderRadius: "100%",
        border: "2px solid",
        borderTopColor: color,
        borderBottomColor: "transparent",
        borderLeftColor: color,
        borderRightColor: color,
        display: "inline-block",
        animation: "".concat(clip, " ").concat(0.75 / speedMultiplier, "s 0s infinite linear"),
        animationFillMode: "both"
    }, cssOverride);
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: style
    }, additionalprops));
}
exports.default = ClipLoader;
}}),
"[project]/node_modules/react-spinners/ClockLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var rotate = (0, animation_1.createAnimation)("ClockLoader", "100% { transform: rotate(360deg) }", "rotate");
function ClockLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 50 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var _g = (0, unitConverter_1.parseLengthAndUnit)(size), value = _g.value, unit = _g.unit;
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: "".concat(value).concat(unit),
        height: "".concat(value).concat(unit),
        backgroundColor: "transparent",
        boxShadow: "inset 0px 0px 0px 2px ".concat(color),
        borderRadius: "50%"
    }, cssOverride);
    var minute = {
        position: "absolute",
        backgroundColor: color,
        width: "".concat(value / 3, "px"),
        height: "2px",
        top: "".concat(value / 2 - 1, "px"),
        left: "".concat(value / 2 - 1, "px"),
        transformOrigin: "1px 1px",
        animation: "".concat(rotate, " ").concat(8 / speedMultiplier, "s linear infinite")
    };
    var hour = {
        position: "absolute",
        backgroundColor: color,
        width: "".concat(value / 2.4, "px"),
        height: "2px",
        top: "".concat(value / 2 - 1, "px"),
        left: "".concat(value / 2 - 1, "px"),
        transformOrigin: "1px 1px",
        animation: "".concat(rotate, " ").concat(2 / speedMultiplier, "s linear infinite")
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: hour
    }), React.createElement("span", {
        style: minute
    }));
}
exports.default = ClockLoader;
}}),
"[project]/node_modules/react-spinners/DotLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var rotate = (0, animation_1.createAnimation)("DotLoader", "100% {transform: rotate(360deg)}", "rotate");
var bounce = (0, animation_1.createAnimation)("DotLoader", "0%, 100% {transform: scale(0)} 50% {transform: scale(1.0)}", "bounce");
function DotLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 60 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size),
        animationFillMode: "forwards",
        animation: "".concat(rotate, " ").concat(2 / speedMultiplier, "s 0s infinite linear")
    }, cssOverride);
    var style = function(i) {
        var _a = (0, unitConverter_1.parseLengthAndUnit)(size), value = _a.value, unit = _a.unit;
        return {
            position: "absolute",
            top: i % 2 ? "0" : "auto",
            bottom: i % 2 ? "auto" : "0",
            height: "".concat(value / 2).concat(unit),
            width: "".concat(value / 2).concat(unit),
            backgroundColor: color,
            borderRadius: "100%",
            animationFillMode: "forwards",
            animation: "".concat(bounce, " ").concat(2 / speedMultiplier, "s ").concat(i === 2 ? "1s" : "0s", " infinite linear")
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }));
}
exports.default = DotLoader;
}}),
"[project]/node_modules/react-spinners/FadeLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var fade = (0, animation_1.createAnimation)("FadeLoader", "50% {opacity: 0.3} 100% {opacity: 1}", "fade");
function FadeLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.height, height = _f === void 0 ? 15 : _f, _g = _a.width, width = _g === void 0 ? 5 : _g, _h = _a.radius, radius = _h === void 0 ? 2 : _h, _j = _a.margin, margin = _j === void 0 ? 2 : _j, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "height",
        "width",
        "radius",
        "margin"
    ]);
    var value = (0, unitConverter_1.parseLengthAndUnit)(margin).value;
    var radiusValue = value + 18;
    var quarter = radiusValue / 2 + radiusValue / 5.5;
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        fontSize: "0",
        top: radiusValue,
        left: radiusValue,
        width: "".concat(radiusValue * 3, "px"),
        height: "".concat(radiusValue * 3, "px")
    }, cssOverride);
    var style = function(i) {
        return {
            position: "absolute",
            width: (0, unitConverter_1.cssValue)(width),
            height: (0, unitConverter_1.cssValue)(height),
            margin: (0, unitConverter_1.cssValue)(margin),
            backgroundColor: color,
            borderRadius: (0, unitConverter_1.cssValue)(radius),
            transition: "2s",
            animationFillMode: "both",
            animation: "".concat(fade, " ").concat(1.2 / speedMultiplier, "s ").concat(i * 0.12, "s infinite ease-in-out")
        };
    };
    var a = __assign(__assign({}, style(1)), {
        top: "".concat(radiusValue, "px"),
        left: "0"
    });
    var b = __assign(__assign({}, style(2)), {
        top: "".concat(quarter, "px"),
        left: "".concat(quarter, "px"),
        transform: "rotate(-45deg)"
    });
    var c = __assign(__assign({}, style(3)), {
        top: "0",
        left: "".concat(radiusValue, "px"),
        transform: "rotate(90deg)"
    });
    var d = __assign(__assign({}, style(4)), {
        top: "".concat(-1 * quarter, "px"),
        left: "".concat(quarter, "px"),
        transform: "rotate(45deg)"
    });
    var e = __assign(__assign({}, style(5)), {
        top: "".concat(-1 * radiusValue, "px"),
        left: "0"
    });
    var f = __assign(__assign({}, style(6)), {
        top: "".concat(-1 * quarter, "px"),
        left: "".concat(-1 * quarter, "px"),
        transform: "rotate(-45deg)"
    });
    var g = __assign(__assign({}, style(7)), {
        top: "0",
        left: "".concat(-1 * radiusValue, "px"),
        transform: "rotate(90deg)"
    });
    var h = __assign(__assign({}, style(8)), {
        top: "".concat(quarter, "px"),
        left: "".concat(-1 * quarter, "px"),
        transform: "rotate(45deg)"
    });
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: a
    }), React.createElement("span", {
        style: b
    }), React.createElement("span", {
        style: c
    }), React.createElement("span", {
        style: d
    }), React.createElement("span", {
        style: e
    }), React.createElement("span", {
        style: f
    }), React.createElement("span", {
        style: g
    }), React.createElement("span", {
        style: h
    }));
}
exports.default = FadeLoader;
}}),
"[project]/node_modules/react-spinners/GridLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var grid = (0, animation_1.createAnimation)("GridLoader", "0% {transform: scale(1)} 50% {transform: scale(0.5); opacity: 0.7} 100% {transform: scale(1); opacity: 1}", "grid");
var random = function(top) {
    return Math.random() * top;
};
function GridLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 15 : _f, _g = _a.margin, margin = _g === void 0 ? 2 : _g, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size",
        "margin"
    ]);
    var sizeWithUnit = (0, unitConverter_1.parseLengthAndUnit)(size);
    var marginWithUnit = (0, unitConverter_1.parseLengthAndUnit)(margin);
    var width = parseFloat(sizeWithUnit.value.toString()) * 3 + parseFloat(marginWithUnit.value.toString()) * 6;
    var wrapper = __assign({
        width: "".concat(width).concat(sizeWithUnit.unit),
        fontSize: 0,
        display: "inline-block"
    }, cssOverride);
    var style = function(rand) {
        return {
            display: "inline-block",
            backgroundColor: color,
            width: "".concat((0, unitConverter_1.cssValue)(size)),
            height: "".concat((0, unitConverter_1.cssValue)(size)),
            margin: (0, unitConverter_1.cssValue)(margin),
            borderRadius: "100%",
            animationFillMode: "both",
            animation: "".concat(grid, " ").concat((rand / 100 + 0.6) / speedMultiplier, "s ").concat(rand / 100 - 0.2, "s infinite ease")
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops, {
        ref: function(node) {
            if (node) {
                node.style.setProperty("width", "".concat(width).concat(sizeWithUnit.unit), "important");
            }
        }
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }), React.createElement("span", {
        style: style(random(100))
    }));
}
exports.default = GridLoader;
}}),
"[project]/node_modules/react-spinners/HashLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var colors_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/colors.js [app-client] (ecmascript)");
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
function HashLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 50 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var _g = (0, unitConverter_1.parseLengthAndUnit)(size), value = _g.value, unit = _g.unit;
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size),
        transform: "rotate(165deg)"
    }, cssOverride);
    var thickness = value / 5;
    var lat = (value - thickness) / 2;
    var offset = lat - thickness;
    var colorValue = (0, colors_1.calculateRgba)(color, 0.75);
    var before = (0, animation_1.createAnimation)("HashLoader", "0% {width: ".concat(thickness, "px; box-shadow: ").concat(lat, "px ").concat(-offset, "px ").concat(colorValue, ", ").concat(-lat, "px ").concat(offset, "px ").concat(colorValue, "}\n    35% {width: ").concat((0, unitConverter_1.cssValue)(size), "; box-shadow: 0 ").concat(-offset, "px ").concat(colorValue, ", 0 ").concat(offset, "px ").concat(colorValue, "}\n    70% {width: ").concat(thickness, "px; box-shadow: ").concat(-lat, "px ").concat(-offset, "px ").concat(colorValue, ", ").concat(lat, "px ").concat(offset, "px ").concat(colorValue, "}\n    100% {box-shadow: ").concat(lat, "px ").concat(-offset, "px ").concat(colorValue, ", ").concat(-lat, "px ").concat(offset, "px ").concat(colorValue, "}"), "before");
    var after = (0, animation_1.createAnimation)("HashLoader", "0% {height: ".concat(thickness, "px; box-shadow: ").concat(offset, "px ").concat(lat, "px ").concat(color, ", ").concat(-offset, "px ").concat(-lat, "px ").concat(color, "}\n    35% {height: ").concat((0, unitConverter_1.cssValue)(size), "; box-shadow: ").concat(offset, "px 0 ").concat(color, ", ").concat(-offset, "px 0 ").concat(color, "}\n    70% {height: ").concat(thickness, "px; box-shadow: ").concat(offset, "px ").concat(-lat, "px ").concat(color, ", ").concat(-offset, "px ").concat(lat, "px ").concat(color, "}\n    100% {box-shadow: ").concat(offset, "px ").concat(lat, "px ").concat(color, ", ").concat(-offset, "px ").concat(-lat, "px ").concat(color, "}"), "after");
    var style = function(i) {
        return {
            position: "absolute",
            top: "50%",
            left: "50%",
            display: "block",
            width: "".concat(value / 5).concat(unit),
            height: "".concat(value / 5).concat(unit),
            borderRadius: "".concat(value / 10).concat(unit),
            transform: "translate(-50%, -50%)",
            animationFillMode: "none",
            animation: "".concat(i === 1 ? before : after, " ").concat(2 / speedMultiplier, "s infinite")
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }));
}
exports.default = HashLoader;
}}),
"[project]/node_modules/react-spinners/MoonLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var moon = (0, animation_1.createAnimation)("MoonLoader", "100% {transform: rotate(360deg)}", "moon");
function MoonLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 60 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var _g = (0, unitConverter_1.parseLengthAndUnit)(size), value = _g.value, unit = _g.unit;
    var moonSize = Math.round(value / 7);
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: "".concat("".concat(value + moonSize * 2).concat(unit)),
        height: "".concat("".concat(value + moonSize * 2).concat(unit)),
        animation: "".concat(moon, " ").concat(0.6 / speedMultiplier, "s 0s infinite linear"),
        animationFillMode: "forwards"
    }, cssOverride);
    var ballStyle = function(size) {
        return {
            width: (0, unitConverter_1.cssValue)(size),
            height: (0, unitConverter_1.cssValue)(size),
            borderRadius: "100%"
        };
    };
    var ball = __assign(__assign({}, ballStyle(moonSize)), {
        backgroundColor: "".concat(color),
        opacity: "0.8",
        position: "absolute",
        top: "".concat("".concat(value / 2 - moonSize / 2).concat(unit)),
        animation: "".concat(moon, " ").concat(0.6 / speedMultiplier, "s 0s infinite linear"),
        animationFillMode: "forwards"
    });
    var circle = __assign(__assign({}, ballStyle(value)), {
        border: "".concat(moonSize, "px solid ").concat(color),
        opacity: "0.1",
        boxSizing: "content-box",
        position: "absolute"
    });
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: ball
    }), React.createElement("span", {
        style: circle
    }));
}
exports.default = MoonLoader;
}}),
"[project]/node_modules/react-spinners/PacmanLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var pacman = [
    (0, animation_1.createAnimation)("PacmanLoader", "0% {transform: rotate(0deg)} 50% {transform: rotate(-44deg)}", "pacman-1"),
    (0, animation_1.createAnimation)("PacmanLoader", "0% {transform: rotate(0deg)} 50% {transform: rotate(44deg)}", "pacman-2")
];
function PacmanLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 25 : _f, _g = _a.margin, margin = _g === void 0 ? 2 : _g, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size",
        "margin"
    ]);
    var _h = (0, unitConverter_1.parseLengthAndUnit)(size), value = _h.value, unit = _h.unit;
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        fontSize: 0,
        height: "".concat(value * 2).concat(unit),
        width: "".concat(value * 2).concat(unit)
    }, cssOverride);
    var ball = (0, animation_1.createAnimation)("PacmanLoader", "75% {opacity: 0.7}\n    100% {transform: translate(".concat("".concat(-4 * value).concat(unit), ", ").concat("".concat(-value / 4).concat(unit), ")}"), "ball");
    var ballStyle = function(i) {
        return {
            width: "".concat(value / 3).concat(unit),
            height: "".concat(value / 3).concat(unit),
            backgroundColor: color,
            margin: (0, unitConverter_1.cssValue)(margin),
            borderRadius: "100%",
            transform: "translate(0, ".concat("".concat(-value / 4).concat(unit), ")"),
            position: "absolute",
            top: "".concat(value).concat(unit),
            left: "".concat(value * 4).concat(unit),
            animation: "".concat(ball, " ").concat(1 / speedMultiplier, "s ").concat(i * 0.25, "s infinite linear"),
            animationFillMode: "both"
        };
    };
    var s1 = "".concat((0, unitConverter_1.cssValue)(size), " solid transparent");
    var s2 = "".concat((0, unitConverter_1.cssValue)(size), " solid ").concat(color);
    var pacmanStyle = function(i) {
        return {
            width: 0,
            height: 0,
            borderRight: s1,
            borderTop: i === 0 ? s1 : s2,
            borderLeft: s2,
            borderBottom: i === 0 ? s2 : s1,
            borderRadius: (0, unitConverter_1.cssValue)(size),
            position: "absolute",
            animation: "".concat(pacman[i], " ").concat(0.8 / speedMultiplier, "s infinite ease-in-out"),
            animationFillMode: "both"
        };
    };
    var pac = pacmanStyle(0);
    var man = pacmanStyle(1);
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: pac
    }), React.createElement("span", {
        style: man
    }), React.createElement("span", {
        style: ballStyle(2)
    }), React.createElement("span", {
        style: ballStyle(3)
    }), React.createElement("span", {
        style: ballStyle(4)
    }), React.createElement("span", {
        style: ballStyle(5)
    }));
}
exports.default = PacmanLoader;
}}),
"[project]/node_modules/react-spinners/PropagateLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
// 1.5 4.5 7.5
var distance = [
    1,
    3,
    5
];
var propagate = [
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(-".concat(distance[0], "rem) scale(0.75)}\n    50% {transform: translateX(-").concat(distance[1], "rem) scale(0.6)}\n    75% {transform: translateX(-").concat(distance[2], "rem) scale(0.5)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-0"),
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(-".concat(distance[0], "rem) scale(0.75)}\n    50% {transform: translateX(-").concat(distance[1], "rem) scale(0.6)}\n    75% {transform: translateX(-").concat(distance[1], "rem) scale(0.6)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-1"),
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(-".concat(distance[0], "rem) scale(0.75)}\n    75% {transform: translateX(-").concat(distance[0], "rem) scale(0.75)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-2"),
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(".concat(distance[0], "rem) scale(0.75)}\n    75% {transform: translateX(").concat(distance[0], "rem) scale(0.75)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-3"),
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(".concat(distance[0], "rem) scale(0.75)}\n    50% {transform: translateX(").concat(distance[1], "rem) scale(0.6)}\n    75% {transform: translateX(").concat(distance[1], "rem) scale(0.6)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-4"),
    (0, animation_1.createAnimation)("PropagateLoader", "25% {transform: translateX(".concat(distance[0], "rem) scale(0.75)}\n    50% {transform: translateX(").concat(distance[1], "rem) scale(0.6)}\n    75% {transform: translateX(").concat(distance[2], "rem) scale(0.5)}\n    95% {transform: translateX(0rem) scale(1)}"), "propogate-5")
];
function PropagateLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 15 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var _g = (0, unitConverter_1.parseLengthAndUnit)(size), value = _g.value, unit = _g.unit;
    var wrapper = __assign({
        display: "inherit",
        position: "relative"
    }, cssOverride);
    var style = function(i) {
        return {
            position: "absolute",
            fontSize: "".concat(value / 3).concat(unit),
            width: "".concat(value).concat(unit),
            height: "".concat(value).concat(unit),
            background: color,
            borderRadius: "50%",
            animation: "".concat(propagate[i], " ").concat(1.5 / speedMultiplier, "s infinite"),
            animationFillMode: "forwards"
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(0)
    }), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }), React.createElement("span", {
        style: style(3)
    }), React.createElement("span", {
        style: style(4)
    }), React.createElement("span", {
        style: style(5)
    }));
}
exports.default = PropagateLoader;
}}),
"[project]/node_modules/react-spinners/PulseLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var pulse = (0, animation_1.createAnimation)("PulseLoader", "0% {transform: scale(1); opacity: 1} 45% {transform: scale(0.1); opacity: 0.7} 80% {transform: scale(1); opacity: 1}", "pulse");
function PulseLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 15 : _f, _g = _a.margin, margin = _g === void 0 ? 2 : _g, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size",
        "margin"
    ]);
    var wrapper = __assign({
        display: "inherit"
    }, cssOverride);
    var style = function(i) {
        return {
            backgroundColor: color,
            width: (0, unitConverter_1.cssValue)(size),
            height: (0, unitConverter_1.cssValue)(size),
            margin: (0, unitConverter_1.cssValue)(margin),
            borderRadius: "100%",
            display: "inline-block",
            animation: "".concat(pulse, " ").concat(0.75 / speedMultiplier, "s ").concat(i * 0.12 / speedMultiplier, "s infinite cubic-bezier(0.2, 0.68, 0.18, 1.08)"),
            animationFillMode: "both"
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }), React.createElement("span", {
        style: style(3)
    }));
}
exports.default = PulseLoader;
}}),
"[project]/node_modules/react-spinners/PuffLoader.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
var React = __importStar(__turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var unitConverter_1 = (()=>{
    const e = new Error("Cannot find module './helpers/unitConverter'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var animation_1 = __turbopack_require__("[project]/node_modules/react-spinners/helpers/animation.js [app-client] (ecmascript)");
var puff = [
    (0, animation_1.createAnimation)("PuffLoader", "0% {transform: scale(0)} 100% {transform: scale(1.0)}", "puff-1"),
    (0, animation_1.createAnimation)("PuffLoader", "0% {opacity: 1} 100% {opacity: 0}", "puff-2")
];
function PuffLoader(_a) {
    var _b = _a.loading, loading = _b === void 0 ? true : _b, _c = _a.color, color = _c === void 0 ? "#000000" : _c, _d = _a.speedMultiplier, speedMultiplier = _d === void 0 ? 1 : _d, _e = _a.cssOverride, cssOverride = _e === void 0 ? {} : _e, _f = _a.size, size = _f === void 0 ? 60 : _f, additionalprops = __rest(_a, [
        "loading",
        "color",
        "speedMultiplier",
        "cssOverride",
        "size"
    ]);
    var wrapper = __assign({
        display: "inherit",
        position: "relative",
        width: (0, unitConverter_1.cssValue)(size),
        height: (0, unitConverter_1.cssValue)(size)
    }, cssOverride);
    var style = function(i) {
        return {
            position: "absolute",
            height: (0, unitConverter_1.cssValue)(size),
            width: (0, unitConverter_1.cssValue)(size),
            border: "thick solid ".concat(color),
            borderRadius: "50%",
            opacity: "1",
            top: "0",
            left: "0",
            animationFillMode: "both",
            animation: "".concat(puff[0], ", ").concat(puff[1]),
            animationDuration: "".concat(2 / speedMultiplier, "s"),
            animationIterationCount: "infinite",
            animationTimingFunction: "cubic-bezier(0.165, 0.84, 0.44, 1), cubic-bezier(0.3, 0.61, 0.355, 1)",
            animationDelay: i === 1 ? "-1s" : "0s"
        };
    };
    if (!loading) {
        return null;
    }
    return React.createElement("span", __assign({
        style: wrapper
    }, additionalprops), React.createElement("span", {
        style: style(1)
    }), React.createElement("span", {
        style: style(2)
    }));
}
exports.default = PuffLoader;
}}),
"[project]/node_modules/react-spinners/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SyncLoader = exports.SquareLoader = exports.SkewLoader = exports.ScaleLoader = exports.RotateLoader = exports.RiseLoader = exports.RingLoader = exports.PuffLoader = exports.PulseLoader = exports.PropagateLoader = exports.PacmanLoader = exports.MoonLoader = exports.HashLoader = exports.GridLoader = exports.FadeLoader = exports.DotLoader = exports.ClockLoader = exports.ClipLoader = exports.ClimbingBoxLoader = exports.CircleLoader = exports.BounceLoader = exports.BeatLoader = exports.BarLoader = void 0;
var BarLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/BarLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "BarLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(BarLoader_1).default;
    }
});
var BeatLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/BeatLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "BeatLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(BeatLoader_1).default;
    }
});
var BounceLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/BounceLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "BounceLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(BounceLoader_1).default;
    }
});
var CircleLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/CircleLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "CircleLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(CircleLoader_1).default;
    }
});
var ClimbingBoxLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/ClimbingBoxLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "ClimbingBoxLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(ClimbingBoxLoader_1).default;
    }
});
var ClipLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/ClipLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "ClipLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(ClipLoader_1).default;
    }
});
var ClockLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/ClockLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "ClockLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(ClockLoader_1).default;
    }
});
var DotLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/DotLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "DotLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(DotLoader_1).default;
    }
});
var FadeLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/FadeLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "FadeLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(FadeLoader_1).default;
    }
});
var GridLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/GridLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "GridLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(GridLoader_1).default;
    }
});
var HashLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/HashLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "HashLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(HashLoader_1).default;
    }
});
var MoonLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/MoonLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "MoonLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(MoonLoader_1).default;
    }
});
var PacmanLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/PacmanLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "PacmanLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(PacmanLoader_1).default;
    }
});
var PropagateLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/PropagateLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "PropagateLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(PropagateLoader_1).default;
    }
});
var PulseLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/PulseLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "PulseLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(PulseLoader_1).default;
    }
});
var PuffLoader_1 = __turbopack_require__("[project]/node_modules/react-spinners/PuffLoader.js [app-client] (ecmascript)");
Object.defineProperty(exports, "PuffLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(PuffLoader_1).default;
    }
});
var RingLoader_1 = (()=>{
    const e = new Error("Cannot find module './RingLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "RingLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(RingLoader_1).default;
    }
});
var RiseLoader_1 = (()=>{
    const e = new Error("Cannot find module './RiseLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "RiseLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(RiseLoader_1).default;
    }
});
var RotateLoader_1 = (()=>{
    const e = new Error("Cannot find module './RotateLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "RotateLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(RotateLoader_1).default;
    }
});
var ScaleLoader_1 = (()=>{
    const e = new Error("Cannot find module './ScaleLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "ScaleLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(ScaleLoader_1).default;
    }
});
var SkewLoader_1 = (()=>{
    const e = new Error("Cannot find module './SkewLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "SkewLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(SkewLoader_1).default;
    }
});
var SquareLoader_1 = (()=>{
    const e = new Error("Cannot find module './SquareLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "SquareLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(SquareLoader_1).default;
    }
});
var SyncLoader_1 = (()=>{
    const e = new Error("Cannot find module './SyncLoader'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
Object.defineProperty(exports, "SyncLoader", {
    enumerable: true,
    get: function() {
        return __importDefault(SyncLoader_1).default;
    }
});
}}),
}]);

//# sourceMappingURL=_43f059._.js.map