(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cart_page_tsx_6732e4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cart_page_tsx_6732e4._.js",
  "chunks": [
    "static/chunks/_17cefd._.js"
  ],
  "source": "dynamic"
});
