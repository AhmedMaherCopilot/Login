(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_register_page_tsx_9fbca1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_register_page_tsx_9fbca1._.js",
  "chunks": [
    "static/chunks/src_app_register_page_tsx_d0c14f._.js"
  ],
  "source": "dynamic"
});
