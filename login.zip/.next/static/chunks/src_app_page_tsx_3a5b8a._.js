(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_3a5b8a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_3a5b8a._.js",
  "chunks": [
    "static/chunks/_a13038._.js",
    "static/chunks/src_app_page_module_d12eb7.css"
  ],
  "source": "dynamic"
});
