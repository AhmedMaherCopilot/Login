'use client';
import React, { useEffect, useState } from 'react';
import { FadeLoader } from 'react-spinners';
import './page.module.css';
import './globals.css';

export default function Page() {
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [categoriesResponse, productsResponse] = await Promise.all([
          fetch('https://ecommerce.routemisr.com/api/v1/categories'),
          fetch('https://ecommerce.routemisr.com/api/v1/products')
        ]);

        if (!categoriesResponse.ok || !productsResponse.ok) {
          throw new Error('Failed to fetch data');
        }

        const categoriesData = await categoriesResponse.json();
        const productsData = await productsResponse.json();

        setCategories(categoriesData.data || []);
        setProducts(productsData.data || []);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
    
    // Add to cart function
    const addToCart = async (productId:any) => {
    try {
      const response = await fetch('https://ecommerce.routemisr.com/api/v1/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ productId }),
      });
      
      if (!response.ok) {
        alert(new Error('Failed to add product to cart'))
      }
      
      alert('Product added to cart successfully');
    } catch (error) {
      console.error('Error adding product to cart:', error);
    }
  };
  
  return (
    <div className="container">
      {loading && <FadeLoader className="loader" />}
      {error && <p className="error-message">{error}</p>}

      <ul className="products-display line-height">
        {categories.map((category) => (
          <li key={category._id}>
            {category.image && (
              <img className="image" src={category.image} alt={category.name} width={100} height={100} />
            )}
            <p className="title">{category.name}</p>
          </li>
        ))}
      </ul>

      <ul className="products line-height">
        {products.map((product) => (
          <li key={product._id} className="brand-card">
            {product.images?.[0] && (
              <img className="image" src={product.images[0]} alt={product.title} width={100} height={100} />
            )}
            <div>
              <p className="green-title">{product.category?.name}</p>
              <p className="title">{product.title}</p>
              <p className="price">Price: ${product.price}</p>
              <p>⭐{product.ratingsQuantity}</p>
              <button className="btn button bg-green add" onClick={() => addToCart(product._id)}>+ Add</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
