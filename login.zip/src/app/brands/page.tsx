'use client';
import React, { useEffect, useState } from 'react';
import '../globals.css';
import { FadeLoader } from 'react-spinners';

export default function Page() {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBrands = async () => {
      try {
        const response = await fetch('https://ecommerce.routemisr.com/api/v1/brands');
        if (!response.ok) throw new Error('Failed to fetch brands');
        
        const data = await response.json();
        setBrands(data.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBrands();
  }, []);

  return (
    <div className="container">
      {loading ? (
        <div className="loader">
          <FadeLoader />
        </div>
      ) : error ? (
        <p className="error-message">{error}</p>
      ) : brands.length > 0 ? (
        <div className="brands">
          {brands.map((brand) => (
            <div key={brand._id} className="brand-card">
              {brand.image && (
                <img className="brand-image" src={brand.image} alt={brand.name} width={100} height={100} />
              )}
              <p className="brand-title">{brand.name}</p>
            </div>
          ))}
        </div>
      ) : (
        <p>No brands available</p>
      )}
    </div>
  );
}
