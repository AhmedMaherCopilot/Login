'use client';
import React from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import '../globals.css';

export default function Navbar() {
  const path = usePathname();
  const router = useRouter();

  function deleteToken() {
    localStorage.removeItem('token');
    localStorage.removeItem('Username');
    localStorage.removeItem('email');
    localStorage.removeItem('password');

    
    // Redirect to login page after logout
    router.push('/login');
  }
  
  if (localStorage.getItem('token') === null) {
    router.push('/login'); 
    localStorage.removeItem('email');
    localStorage.removeItem('password');
    console.log("token : ", localStorage.getItem('token'))
    localStorage.removeItem('token');
  } 
  //  add if user want to register or login
  if (localStorage.getItem('email') && localStorage.getItem('password') && localStorage.getItem('token') === null) {
    localStorage.removeItem('email');
    localStorage.removeItem('password');
    localStorage.removeItem('token');
    router.push('/login'); 
  }
 
  return (
    <div className='fixed width-100 navbar'>
      <ul>
        <div className='d-flex'>
          <div>
            <i className="fa-solid fa-cart-shopping cart color-green"></i>
          </div>
          <div className='navbar-title'>
            <p className='color-black'>Fresh Cart</p>
          </div>
        </div>
        <ul>
          <li>
            <Link className={path === '/' ? 'active' : 'navbar-color'} href='/'>Home</Link>
          </li>
          <li>
            <Link className={path === '/cart' ? 'active' : 'navbar-color'} href='/cart'>Cart</Link>
          </li>
          <li>
            <Link className={path === '/brands' ? 'active' : 'navbar-color'} href='/brands'>Brands</Link>
          </li>
          <li>
            <Link className={path === '/login' ? 'active' : 'navbar-color'} href='/login'>Login</Link>
          </li>
          <li>
            <Link className={path === '/register' ? 'active' : 'navbar-color'} href='/register'>Register</Link>
          </li>
        </ul>
        <div className='d-flex'>
          <div>
            <i className="fa-solid fa-cart-shopping cart"></i>
            <button onClick={deleteToken} type='button' className='btn'>Sign out</button>
          </div>
        </div>
      </ul>
    </div>
  );
}
