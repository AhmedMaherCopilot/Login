'use client';

import React, { useEffect, useState } from 'react';
import { FadeLoader } from 'react-spinners';
import '../page.module.css';
import '../globals.css';

export default function Page() {
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [token, setToken] = useState(null);
  const userToken:unknown = localStorage.getItem('token');

  useEffect(() => {
    if (!userToken) {
      setError("User is not authenticated. Please log in.");
      setLoading(false);
      return;
    }
    setToken(userToken);
  }, []);

  useEffect(() => {
    if (!token) return; // Prevents running the fetch before the token is set

    const fetchCart = async () => {
      try {
        const response = await fetch(`https://ecommerce.routemisr.com/api/v1/cart?token=${token}`);
        if (!response.ok) throw new Error('Failed to fetch cart. Check your token or API.');

        const data = await response.json();
        setCart(data.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCart();
  }, [token]); // Dependency ensures the fetch only runs when the token is set

  return (
    <div className="container div-login">
      {loading ? (
        <div className="loader">
          <FadeLoader />
        </div>
      ) : error ? (
        <p className="error-message">{error}</p>
      ) : cart.length > 0 ? (
        <div className="cart">
          {cart.map((item) => (
            <div key={item._id} className="cart-item">
              {item.image && (
                <img className="cart-image" src={item.image} alt={item.name} width={100} height={100} />
              )}
              <p className="cart-title">{item.name}</p>
              <p className="cart-price">${item.price}</p>
            </div>
          ))}
        </div>
      ) : (
        <p>No items in cart</p>
      )}
    </div>
  );
}
