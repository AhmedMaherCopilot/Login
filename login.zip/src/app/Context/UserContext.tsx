// User context

import { createContext } from 'react';

let usercontext = createContext({});

export default function UserProvider(props: any) {
    return <usercontext.Provider value={{}}>
        {props.children}
    </usercontext.Provider>
}