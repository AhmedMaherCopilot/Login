// TokenProvider

import React, { createContext, useState } from 'react';

export const tokencontext = createContext({});

export default function TokenProvider(props: any) {
    const [token, setToken] = useState('');
    return <tokencontext.Provider value={{ token, setToken }}>
        {props.children}
    </tokencontext.Provider>
}