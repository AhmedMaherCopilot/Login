import { createContext } from "react";

let cartcontext = createContext()

export default function CartcontextProvider(props:any){

    return <cartcontext.Provider value={{}}>
        {props.children}
    </cartcontext.Provider>
}