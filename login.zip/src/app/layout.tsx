'use client';
import React, { useEffect } from 'react'
import './globals.css'
import Navbar from './_navbar/page'
import '../../node_modules/@fortawesome/fontawesome-free/css/all.min.css'

export default function page({children}:any) {

  return (

    <html>
    <head></head>
    <body>
      <Navbar />
      {children}
    </body>
    </html>
  )
}
