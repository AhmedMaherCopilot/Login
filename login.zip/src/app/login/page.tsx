'use client';
import { useRouter } from 'next/navigation';
import '../globals.css';
import React, { useState, useEffect } from 'react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      router.push('/');
    }


    if (localStorage.getItem('email') && localStorage.getItem('password') && !token === null) {
      localStorage.removeItem('email');
      localStorage.removeItem('password');
      localStorage.removeItem('token');
      router.push('/login'); 
    }
    else if (localStorage.getItem('email') && localStorage.getItem('password') === null) {
      window.location.href = '/register';
    }
  }, [router]);

  const handleLogin = async () => {
    try {
      const response = await fetch('https://ecommerce.routemisr.com/api/v1/auth/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();

      if (!response.ok) throw new Error('Failed to log in!');

      localStorage.setItem('token', data.token);
      localStorage.setItem('email', email);
      localStorage.setItem('password', password);

      console.log("token : ", localStorage.getItem('token'))

      router.push('/');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className='div-login'><br />
      <h1>Login now</h1>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <form onSubmit={(e) => e.preventDefault()}>
        <label htmlFor="email">Email: </label>
        <input type="text" id="email" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)} /><br />

        <label htmlFor="password">Password: </label>
        <input type="password" id="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} /><br />

        <p className='forget-pass'><a href="">Forget your password?</a></p>

        <button className='login-button' onClick={handleLogin}>Login now</button>
      </form>
    </div>
  );
}
