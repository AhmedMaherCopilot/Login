// register page
'use client';
import { useRouter } from 'next/navigation';
import '../globals.css';
import React, { useState, useEffect } from 'react';

export default function registerPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [repassword, setRepassword] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  if (localStorage.getItem('email') && localStorage.getItem('password') && localStorage.getItem('token') === null) {
    window.location.href = '/register';
  }


  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      router.push('/');
    }
    else {
      router.push('/register');
    }



    if (localStorage.getItem('email') && localStorage.getItem('password') && !token === null) {
      localStorage.removeItem('email');
      localStorage.removeItem('password');
      localStorage.removeItem('token');
      router.push('/register');
    }
  }, [router]);

  const handleregister = async () => {
    try {
      const response = await fetch('https://ecommerce.routemisr.com/api/v1/auth/signup', {
        
      });
      const data = await response.json();

      console.log(data.message)
      // if (!response.ok) throw new Error(data.message);
      if (!response.ok) throw new Error(data.statusMsg);
      localStorage.setItem('token', data.token);
      localStorage.setItem('email', email);
      localStorage.setItem('password', password);
      localStorage.setItem('name', name);
      localStorage.setItem('repassword', repassword);
      localStorage.setItem('phone', phone);
      console.log("token : ", localStorage.getItem('token'))
      router.push('/login');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className='div-login'><br />
      <h1>register now      </h1>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <form onSubmit={(e) => e.preventDefault()}>
        <label htmlFor="Name">Name: </label>
        <input
          type="text"
          id="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        ></input><br />
        <label htmlFor="Email">Email: </label>
        <input
          type="text"
          id="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)
          }
        ></input><br />
        <label htmlFor="Password">Password: </label>
        <input
          type="text"
          id="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        ></input><br />
        <label htmlFor="Re-password">Re-password: </label>
        <input
          type="text"
          id="Re-password"
          value={repassword}
          onChange={(e) => setRepassword(e.target.value)}
        ></input><br />
        <label htmlFor="Phone">Phone : </label>
        <input
          type="text"
          id="Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        ></input><br />

        <button className='register-button' onClick={handleregister}>register now</button>
      </form>
    </div>
  );
}

