'use client';
import React, { useContext } from 'react'
import { tokencontext } from '../Context/Tokenprovider';
import { Navigate } from 'react-router-dom';

export default function ProtectedRoutes( {children}: any ) {
  const { token }:any = useContext(tokencontext)
  console.log("Token : ", token)
  if (token) return <Navigate to="/" />;
  else return {children};
}
