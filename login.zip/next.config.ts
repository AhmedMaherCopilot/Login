import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  pageExtensions: ["tsx", "ts"], // Only allow .tsx and .ts pages
  webpack: (config, { dev }) => {
    if (dev) {
      // Remove Fast Refresh (Hot Reload)
      config.plugins = config.plugins.filter(
        (plugin) => plugin.constructor.name !== "ReactRefreshPlugin"
      );
    }
    return config;
  },
  devIndicators: {
    buildActivity: false, // Disables loading indicators
    autoPrerender: false, // Stops automatic pre-rendering refresh
  },
  onDemandEntries: {
    maxInactiveAge: 1000 * 60 * 60 * 24, // Keep inactive pages for 24 hours
    pagesBufferLength: 50, // Increase cached pages
  },
};

export default nextConfig;
